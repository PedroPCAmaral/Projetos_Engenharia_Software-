#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main() {
    int i, qnt_acima_media = 0;
	float notas[20], media = 0;
    srand((unsigned) time (NULL));
    
    

    
    for (int i = 0; i < 20; i++) {
        notas[i] = rand() % 101 / 10.0; 
        printf ("Nota do estudante %d: %.1f\n" , i + 1, notas[i]);
		media += notas[i];
    }

    media /=20;
    printf("Media: %.2f\n", media);
    
    for (i = 0; i < 20; i++) {
    	if (notas[i] > media){
    		qnt_acima_media++;
		}
	}


  
    printf("Numero de alunos acima da media: %d\n", qnt_acima_media);

    return 0;
}
