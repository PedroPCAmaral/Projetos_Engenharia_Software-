#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main() {
    int numeros[20];
    int novo_numero;
    int novo_vetor[20];
    int n = 0;
    
    
    
    

    srand(time(0));




    
    for (int i = 0; i < 20; i++) {
        numeros[i] = rand() % 100 + 1; 
    }
    
    

    
    novo_numero = rand() % 100 + 1; 
    printf("numeros no vetor: ");
    for (int i = 0; i < 20; i++) {
        printf("%d ", numeros[i]);
        
        
        
        
    }
    printf("\nnumero a ser verificado: %d\n", novo_numero);

    
    for (int i = 0; i < 20; i++) {
        if (numeros[i] != novo_numero) {
            novo_vetor[n++] = numeros[i];
        }
    }

    if (n < 20) {
        printf("numero %d encontrado e removido.\n", novo_numero);
    } else {
    	
    	
        printf("numero %d não encontrado.\n", novo_numero);
    }

    
    printf("novo vetor: ");
    
    
    for (int i = 0; i < n; i++) {
        printf("%d ", novo_vetor[i]);
    }
   
   
    printf("\n");

    
	
	return 0;
}
