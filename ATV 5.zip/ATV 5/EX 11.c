#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int V1[15], V2[15];
    int contador = 0;



    srand(time(0));




    
    printf("Vetor V1:\n");
    
    
    for (int i = 0; i < 15; i++) {
        V1[i] = rand() % 100 + 1; 
        
		
		
		printf("%d ", V1[i]);
    }
    
	
	printf("\n");

    printf("Vetor V2:\n");
   
   
    for (int i = 0; i < 15; i++) {
        V2[i] = rand() % 100 + 1; 
        
		
		printf("%d ", V2[i]);
    }
    
	
	
	printf("\n");

    
    for (int i = 0; i < 15; i++) {
        if (V1[i] == V2[i]) {
            contador++;
        }
    }

    printf("quantidade de numeros iguais nas mesmas posicoes: %d\n", contador);

    
	return 0;
}

