
#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main() {
    int numeros[30];
    int numero_procurado, contador = 0;

   
   
    srand(time(0));

    
    for (int i = 0; i < 30; i++) {
    	
        numeros[i] = rand() % 100 + 1; 
    }



    numero_procurado = rand() % 100 + 1;
    
	
	printf("numeros no vetor: ");
    
	
	for (int i = 0; i < 30; i++) {
     
	 
	    printf("%d ", numeros[i]);
    }
    
	
	printf("\nnumero procurado: %d\n", numero_procurado);



    for (int i = 0; i < 30; i++) {
        if (numeros[i] == numero_procurado) {
            contador++;
        }
    }

    printf("numero %d aparece %d vez(es) no vetor.\n", numero_procurado, contador);

    return 0;
}



