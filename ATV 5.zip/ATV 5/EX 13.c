#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int VET[50];
    int repetido;



    srand(time(0));



    for (int i = 0; i < 50; i++) {
        VET[i] = rand() % 100 + 1; 
    }


    printf("vetor:\n");
   
    for (int i = 0; i < 50; i++) {



        printf("%d ", VET[i]);
    }


    printf("\n");

    printf("numeros repetidos e suas posicoes:\n");
   
   
    for (int i = 0; i < 50; i++) {
        
		repetido = VET[i];
        int encontrado = 0;
        for (int j = i + 1; j < 50; j++) {
            if (VET[j] == repetido) {
                encontrado = 1;
                break;
            }
        }
        if (encontrado) {
           
		    printf("numero %d encontrado nas posições: ", repetido);
           
		   
		    for (int j = 0; j < 50; j++) {
                if (VET[j] == repetido) {
                    printf("%d ", j);
                }
            }
            
			printf("\n");
           
		   
		    
            for (int k = i + 1; k < 50; k++) {
                if (VET[k] == repetido) {
                    for (int m = k; m < 49; m++) {
                        VET[m] = VET[m + 1];
                    }
                    i--; 
                    break;
                }
            }
        }
    }
    
    

    return 0;
}

