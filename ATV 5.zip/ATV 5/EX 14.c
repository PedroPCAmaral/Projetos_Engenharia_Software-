#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    
	int matriz[3][3];
    
	int determinante;

    srand(time(0));
    

    
    printf("matriz 3x3:\n");
    
	
	for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            matriz[i][j] = rand() % 10; 
           
		   
		    printf("%d ", matriz[i][j]);
        }
       
	   
	    printf("\n");
    }

    
    determinante = matriz[0][0] * (matriz[1][1] * matriz[2][2] - matriz[1][2] * matriz[2][1]) -
                   matriz[0][1] * (matriz[1][0] * matriz[2][2] - matriz[1][2] * matriz[2][0]) +
                   matriz[0][2] * (matriz[1][0] * matriz[2][1] - matriz[1][1] * matriz[2][0]);

    
	
	printf("determinante da matriz: %d\n", determinante);

    
	
	return 0;
}
