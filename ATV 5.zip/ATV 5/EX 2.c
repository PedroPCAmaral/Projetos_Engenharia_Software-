
#include <stdio.h>
#include <stdlib.h>
#include <time.h>




int main() {
    int Q[20];
    int maior, posicao;

    srand(time(0));

    
    for (int i = 0; i < 20; i++) {
        Q[i] = rand() % 100 + 1; 
    }

    maior = Q[0];
    posicao = 0;

    
    for (int i = 1; i < 20; i++) {
        if (Q[i] > maior) {
            maior = Q[i];
            posicao = i;
        }
    }

    printf("maior elemento: %d na posição %d\n", maior, posicao);
    return 0;
}
