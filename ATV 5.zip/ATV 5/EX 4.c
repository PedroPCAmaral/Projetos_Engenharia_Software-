#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int A[10], M[10];
    int X;

    srand(time(0));

    
    for (int i = 0; i < 10; i++) {
        A[i] = rand() % 10 + 1; 
        
        
    }



    X = rand() % 10 + 1; 
    
    
    

    
    for (int i = 0; i < 10; i++) {
        M[i] = A[i] * X;
    }
    
    
    


    printf("vetor A: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", A[i]);
    }
    
    
    printf("\nvalor de X: %d\n", X);
    
    
    
    printf("vetor M: ");
    for (int i = 0; i < 10; i++) {
    
	    printf("%d ", M[i]);
    }
    
    
    printf("\n");



    return 0;
}
