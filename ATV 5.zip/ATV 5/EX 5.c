
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main() {
    int numeros[20];
    
    

    srand(time(0));


    for (int i = 0; i < 20; i++) {
        numeros[i] = rand() % 100 + 1;
    }

    
    printf("numeros na ordem inversa: ");
    for (int i = 19; i >= 0; i--) {
        printf("%d ", numeros[i]);
    }
    
    
    printf("\n");



    return 0;
}

