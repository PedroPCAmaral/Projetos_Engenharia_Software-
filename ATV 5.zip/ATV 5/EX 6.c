#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main() {
    int N = 5; 
    int A[N], B[N], Soma[N];



    srand(time(0));



    
    printf("vetor A:\n");
    for (int i = 0; i < N; i++) {
        A[i] = rand() % 100 + 1; 
        printf("%d ", A[i]);
    }
    
    
    
    printf("\n");



    
    printf("vetor B:\n");
    for (int i = 0; i < N; i++) {
        B[i] = rand() % 100 + 1; 
        printf("%d ", B[i]);
    }
    
    
    printf("\n");



    
    for (int i = 0; i < N; i++) {
        Soma[i] = A[i] + B[i];
    }



    
    printf("vetor soma: ");
    for (int i = 0; i < N; i++) {
        printf("%d ", Soma[i]);
    }
    
    
    printf("\n");



    return 0;
}

