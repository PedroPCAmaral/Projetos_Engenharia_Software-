#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main() {
    float temperaturas[365];
    float soma = 0, media;
    int dias_inferior_media = 0, menor, maior;



    srand(time(0));
    

    
    for (int i = 0; i < 365; i++) {
        temperaturas[i] = (float)(rand() % 351) / 10;
        soma += temperaturas[i];
    }


    media = soma / 365;
    menor = temperaturas[0];
    maior = temperaturas[0];





    for (int i = 0; i < 365; i++) {
        if (temperaturas[i] < menor) {
            menor = temperaturas[i];
        }
        if (temperaturas[i] > maior) {
            maior = temperaturas[i];
        }
        if (temperaturas[i] < media) {
            dias_inferior_media++;
        }
    }
    
    
    

    printf("menor temperatura: %.2f\n", menor);
    printf("maior temperatura: %.2f\n", maior);
    printf("temperatura media anual: %.2f\n", media);
    printf("dias com temperatura inferior a media: %d\n", dias_inferior_media);




    return 0;
}




