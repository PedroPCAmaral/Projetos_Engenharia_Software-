#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void bubble_sort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                
                
                
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int numeros[10];


    srand(time(0));


    
    for (int i = 0; i < 10; i++) {
        numeros[i] = rand() % 100 + 1; 
    }


    printf("Vetor original: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", numeros[i]);
    }
    printf("\n");

    
    
    
    
    bubble_sort(numeros, 10);

    
    
    
    
    printf("vetor ordenado: ");
    for (int i = 0; i < 10; i++) {
        printf("%d ", numeros[i]);
    }
    
    
    printf("\n");
    
    

    return 0;
}

    
    
    
   
