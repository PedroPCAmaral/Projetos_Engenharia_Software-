#include <stdio.h>
#include <stdlib.h>
#include <time.h>




void inserir_ordenado(int arr[], int *n, int novo_numero) {
    int i;
    
    
    for (i = *n - 1; (i >= 0 && arr[i] > novo_numero); i--) {
        arr[i + 1] = arr[i];
    }
    arr[i + 1] = novo_numero;
    (*n)++;
}

int main() {
    int numeros[11];
    int novo_numero;
    int n = 10;

    srand(time(0));

    
    for (int i = 0; i < n; i++) {
        numeros[i] = rand() % 100 + 1; 
    }
    
    


    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (numeros[j] > numeros[j + 1]) {
                
                
                
                int temp = numeros[j];
                numeros[j] = numeros[j + 1];
                numeros[j + 1] = temp;
            }
        }
    }

    printf("Vetor original: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", numeros[i]);
    }
    
    
    printf("\n");
    
    
    

    novo_numero = rand() % 100 + 1;
    
    
    printf("numero a ser inserido: %d\n", novo_numero);
    

    inserir_ordenado(numeros, &n, novo_numero);
    

    
    
    printf("vetor apos insercao: ");
    
    
    for (int i = 0; i < n; i++) {
        printf("%d ", numeros[i]);
    }
    
	
	printf("\n");

   
   
    return 0;
    
}


